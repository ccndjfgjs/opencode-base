// McpNativeGatewayValidation.h — canonical execute validation for the unreal gateway
//
// Stage order is normative and matches the TypeScript reference
// (src/server/gateway/gateway-execute*.ts): resolve form and alias ->
// registry -> dynamic enabled state -> options -> defaults -> exact per-action
// input schema. Nothing reaches the subsystem queue until every stage passes.

#pragma once

#include "CoreMinimal.h"
#include "Dom/JsonObject.h"
#include "Dom/JsonValue.h"
#include "Foundation/McpLiveStateRevisions.h"

class FMcpToolRegistry;
class FMcpDynamicToolManager;
struct FMcpReceiptContext;

struct FMcpGatewayExecutePlan
{
	FString CapabilityId;
	FString ParentTool;

	/** Client-facing action carried in the payload, not routing.dispatchAction. */
	FString LegacyAction;

	/** Automation action on the wire, resolved from the registry dispatch pattern. */
	FString DispatchAction;

	TSharedPtr<FJsonObject> Arguments;
	TSharedPtr<FJsonObject> OutputSchema;

	/**
	 * Client live-state pins, parsed but deliberately NOT compared here. The
	 * comparison belongs on the game thread immediately before mutation; a
	 * transport-thread comparison would be stale by dispatch time.
	 */
	TMap<EMcpStateKind, int64> ExpectedRevisions;

	/** Parameters the call sent that only other variants of its folded family read. */
	TArray<FString> Warnings;
};

/**
 * Validate one gateway execute payload.
 *
 * Returns nullptr when OutPlan is ready to dispatch; otherwise returns the
 * semantic error receipt to send back unchanged. Rejects unknown capabilities,
 * ambiguous aliases, conflicting request forms, disabled capabilities,
 * unsupported options, and any input the exact per-action schema refuses.
 * Context gains the request's provenance once it resolves, so every receipt carries it.
 */
TSharedPtr<FJsonObject> ValidateAndResolveGatewayExecute(
	const TSharedPtr<FJsonObject>& GatewayParams,
	const FMcpToolRegistry& Registry, const FMcpDynamicToolManager& ToolManager,
	FMcpReceiptContext& Context, FMcpGatewayExecutePlan& OutPlan);

/**
 * Project a handler result to the capability's declared output fields.
 *
 * Mirrors the TypeScript gateway (projectCanonicalOutput): keeps only the
 * declared output properties, reading each from the result root and then from
 * its nested `data` payload. Undeclared native transport/verification fields are
 * dropped so a real success payload can never violate its closed output schema.
 */
TSharedPtr<FJsonObject> McpProjectCanonicalOutput(
	const TSharedPtr<FJsonObject>& Result, const TSharedPtr<FJsonObject>& OutputSchema);

/**
 * Validate a projected canonical output against the capability output schema.
 *
 * Returns nullptr when the canonical output conforms; otherwise the error
 * receipt. The raw handler payload is preserved on the error as structured
 * Unreal detail so a schema violation never discards what Unreal reported.
 */
TSharedPtr<FJsonObject> ValidateGatewayExecuteOutput(
	const FString& CapabilityId, const TSharedPtr<FJsonObject>& OutputSchema,
	const TSharedPtr<FJsonObject>& CanonicalOutput, const TSharedPtr<FJsonObject>& RawResult,
	const FMcpReceiptContext& Context);

