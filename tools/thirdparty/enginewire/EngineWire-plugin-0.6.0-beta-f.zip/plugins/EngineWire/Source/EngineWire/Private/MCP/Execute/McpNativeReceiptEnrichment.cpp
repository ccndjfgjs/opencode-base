#include "MCP/Execute/McpNativeReceiptEnrichment.h"
#include "Foundation/HandlerUtils/McpHandlerUtilsJson.h"
// McpNativeReceiptEnrichment.cpp — see header for the parity contract.

#include "MCP/Gateway/McpNativeGatewayCanonicalJson.h"
#include "Misc/SecureHash.h"
#include "MCP/Execute/McpNativeReceiptRedaction.h"
#include "MCP/Execute/McpNativeReceiptOutcome.h"
#include "MCP/Execute/McpNativeGatewayReceipt.h"
#include "MCP/Execute/McpNativeGatewayCanonicalRecords.h"
#include "MCP/Gateway/McpNativeGatewayCapabilityStore.h"
#include "MCP/Gateway/McpNativeGatewayCatalog.h"
#include "HAL/PlatformTime.h"

void McpSetReceiptRecordRevisions(const TSharedPtr<FJsonObject>& Receipt, const FString& CapabilityId)
{
	if (CapabilityId.IsEmpty())
	{
		return;
	}
	const FMcpCapabilityRecord* Record = FMcpCanonicalRecordIndex::Get().FindById(CapabilityId);
	if (Record == nullptr || !Record->Hashes.IsValid())
	{
		return;
	}
	FString Content;
	if (Record->Hashes->TryGetStringField(TEXT("content"), Content))
	{
		Receipt->SetStringField(TEXT("capabilityRevision"), Content);
	}
	FString Schema;
	if (Record->Hashes->TryGetStringField(TEXT("schema"), Schema))
	{
		Receipt->SetStringField(TEXT("schemaRevision"), Schema);
	}
}

namespace
{
TSharedPtr<FJsonObject> BuildCanonicalError(const FMcpSemanticError& Error)
{
	TSharedPtr<FJsonObject> Object = MakeShared<FJsonObject>();
	Object->SetStringField(TEXT("kind"), Error.Kind);
	Object->SetStringField(TEXT("code"), Error.Code);
	Object->SetStringField(TEXT("message"), McpRedactText(Error.Message));
	if (!Error.Pointer.IsEmpty()) Object->SetStringField(TEXT("pointer"), Error.Pointer);
	if (!Error.Option.IsEmpty()) Object->SetStringField(TEXT("option"), Error.Option);
	if (!Error.Field.IsEmpty()) Object->SetStringField(TEXT("field"), Error.Field);
	if (!Error.CurrentRevision.IsEmpty()) Object->SetStringField(TEXT("currentRevision"), Error.CurrentRevision);
	if (!Error.ExpectedRevision.IsEmpty()) Object->SetStringField(TEXT("expectedRevision"), Error.ExpectedRevision);
	if (Error.bHasRetryable) Object->SetBoolField(TEXT("retryable"), Error.bRetryable);
	if (Error.Supported.Num() > 0)
	{
		TArray<TSharedPtr<FJsonValue>> Supported;
		for (const FString& Item : Error.Supported)
		{
			Supported.Add(MakeShared<FJsonValueString>(Item));
		}
		Object->SetArrayField(TEXT("supported"), Supported);
	}
	return Object;
}
}  // namespace

FString McpCanonicalizeRequestId(const TSharedPtr<FJsonValue>& Id)
{
	if (!Id.IsValid())
	{
		return FString();
	}
	if (Id->Type == EJson::String)
	{
		FString Text;
		McpHandlerUtils::TryGetJsonValueString(Id, Text);
		return TEXT("str:") + Text;
	}
	if (Id->Type == EJson::Number)
	{
		const double Number = Id->AsNumber();
		if (Number == FMath::TruncToDouble(Number))
		{
			return FString::Printf(TEXT("num:%lld"), static_cast<int64>(Number));
		}
		return FString::Printf(TEXT("num:%g"), Number);
	}
	return FString();
}

// receipt.warnings was filled from DeprecationWarnings() alone, so everything a
// handler actually warned about -- captured engine errors, "the handler still
// reports success" disclosures -- sat in data.details.warnings where no caller
// checking the receipt would look. Harvest those too. Niagara stack errors are
// left where they are: add_niagara_module declares stackErrors, so a copy here
// only repeated each one.
static void McpCollectResultWarnings(const TSharedPtr<FJsonObject>& Source,
                                     TArray<FString>& Out)
{
	if (!Source.IsValid())
	{
		return;
	}
	const TArray<TSharedPtr<FJsonValue>>* Values = nullptr;
	if (Source->TryGetArrayField(TEXT("warnings"), Values) && Values)
	{
		for (const TSharedPtr<FJsonValue>& Value : *Values)
		{
			const FString Text = Value.IsValid() ? Value->AsString() : FString();
			if (!Text.IsEmpty())
			{
				Out.AddUnique(Text);
			}
		}
	}
	const TSharedPtr<FJsonObject>* Details = nullptr;
	if (Source->TryGetObjectField(TEXT("details"), Details) && Details)
	{
		McpCollectResultWarnings(*Details, Out);
	}
}

// A world edit made while Play-In-Editor runs lands in the PIE world and is
// discarded when play stops; the only trace was a UEDPIE_ prefix buried in
// details.worldName, so a caller editing "the level" while someone was playing
// believed a whole spawn batch had stuck. Mirrors pieWorldWarnings() in
// gateway-execute-dispatch.ts; the caller has already excluded read capabilities.
static void McpAddPieWorldWarning(const FString& CapabilityId,
                                  const TSharedPtr<FJsonObject>& Source,
                                  TArray<FString>& Out)
{
	if (!Source.IsValid() || !(CapabilityId.StartsWith(TEXT("control_actor.")) ||
	                           CapabilityId.StartsWith(TEXT("build_environment."))))
	{
		return;
	}
	FString World;
	bool bPaused = false, bDetailsPaused = false;
	const TSharedPtr<FJsonObject>* Details = nullptr;
	if (Source->TryGetObjectField(TEXT("details"), Details) && Details)
	{
		(*Details)->TryGetStringField(TEXT("worldName"), World);
		(*Details)->TryGetBoolField(TEXT("gamePaused"), bDetailsPaused);
	}
	Source->TryGetStringField(TEXT("worldName"), World);
	Source->TryGetBoolField(TEXT("gamePaused"), bPaused);
	bPaused = bPaused || bDetailsPaused;
	if (World.Contains(TEXT("/UEDPIE_")))
	{
		Out.AddUnique(FString::Printf(TEXT("Applied to the running Play-In-Editor world (%s): the change is discarded when play stops and the editor level is unchanged. Stop PIE first to edit the level."), *World));
	}
	if (bPaused)
	{
		Out.AddUnique(TEXT("The game is paused (a title screen, a pause menu or control_editor pause): nothing it moves or simulates advances until play resumes (control_editor resume with unpauseGame)."));
	}
}

TSharedPtr<FJsonObject> McpBuildCanonicalReceipt(
	const FString& CapabilityId, const FMcpReceiptContext& Context,
	bool bSuccess, const FMcpSemanticError* Error,
	const TSharedPtr<FJsonObject>& Data, const TSharedPtr<FJsonObject>& RawResult)
{
	TSharedPtr<FJsonObject> Receipt = MakeShared<FJsonObject>();
	Receipt->SetStringField(TEXT("status"), bSuccess ? TEXT("success") : TEXT("error"));
	Receipt->SetStringField(TEXT("capabilityId"), CapabilityId);
	if (!Context.CorrelationId.IsEmpty()) Receipt->SetStringField(TEXT("correlationId"), Context.CorrelationId);
	if (!Context.RequestId.IsEmpty()) Receipt->SetStringField(TEXT("requestId"), Context.RequestId);
	if (!Context.IdempotencyId.IsEmpty()) Receipt->SetStringField(TEXT("idempotencyId"), Context.IdempotencyId);
	Receipt->SetStringField(TEXT("catalogRevision"), FMcpCanonicalRecordIndex::Get().GetCatalogRevision());
	McpSetReceiptRecordRevisions(Receipt, CapabilityId);
	if (Context.StartTimeSeconds > 0.0)
	{
		const double Ms = (FPlatformTime::Seconds() - Context.StartTimeSeconds) * 1000.0;
		Receipt->SetNumberField(TEXT("timingMs"), Ms > 0.0 ? FMath::FloorToDouble(Ms) : 0.0);
	}
	Receipt->SetArrayField(TEXT("nextCalls"), TArray<TSharedPtr<FJsonValue>>());

	if (bSuccess)
	{
		Receipt->SetArrayField(TEXT("handles"),
			McpBoundJsonArray(McpExtractReceiptHandles(RawResult)));
		// changes[] is derived from assetPath/actorPath in the result, which read
		// capabilities also carry -- so inspect_graph, get_blueprint, get_scs and
		// friends all reported the object they had merely looked at as changed.
		// changes[] is the mutation record: only a writing capability may fill it.
		const FMcpCapabilityRecord* EffectRecord =
			FMcpCanonicalRecordIndex::Get().FindById(CapabilityId);
		const bool bMutates = !EffectRecord || !EffectRecord->Effect.Equals(TEXT("read"), ESearchCase::IgnoreCase);
		TArray<TSharedPtr<FJsonValue>> Changes;
		if (bMutates)
		{
			for (const FString& Change : McpExtractReceiptChanges(RawResult))
			{
				Changes.Add(MakeShared<FJsonValueString>(McpRedactText(Change)));
			}
		}
		Receipt->SetArrayField(TEXT("changes"), McpBoundJsonArray(MoveTemp(Changes)));
		TArray<FString> WarningTexts;
		McpCollectResultWarnings(RawResult, WarningTexts);
		McpCollectResultWarnings(Data, WarningTexts);
		for (const FString& Warning : Context.GatewayWarnings)
		{
			WarningTexts.AddUnique(Warning);
		}
		if (bMutates)
		{
			McpAddPieWorldWarning(CapabilityId, RawResult, WarningTexts);
			McpAddPieWorldWarning(CapabilityId, Data, WarningTexts);
		}
		TArray<TSharedPtr<FJsonValue>> Warnings;
		for (const FString& Warning : WarningTexts)
		{
			Warnings.Add(MakeShared<FJsonValueString>(McpRedactText(Warning)));
		}
		Receipt->SetArrayField(TEXT("warnings"), McpBoundJsonArray(MoveTemp(Warnings)));
		TSharedPtr<FJsonObject> Validation = MakeShared<FJsonObject>();
		Validation->SetStringField(TEXT("outputSchema"), TEXT("passed"));
		Receipt->SetObjectField(TEXT("validation"), Validation);
		if (const TSharedPtr<FJsonObject> Task = McpExtractReceiptTask(RawResult))
		{
			Receipt->SetObjectField(TEXT("task"), Task);
		}
		// The payload is published once at the top level; the receipt binds to the masked payload
		// through a digest instead of repeating it (dogfood #11). Mirrors dataDigestOf() in envelope.ts.
		TSharedPtr<FJsonObject> Published = Data.IsValid() ? Data : MakeShared<FJsonObject>();
		McpMaskSecretsDeep(Published);
		FString CanonicalData;
		// Fractions allowed, as the idempotency fingerprint does: without them the render
		// stopped at the first non-integer, so every motion sample (56.2...) hashed the same prefix.
		McpCanonicalJsonObject(Published, CanonicalData, /*bAllowFractions=*/true);
		const FTCHARToUTF8 Utf8(*CanonicalData);
		uint8 Hash[20];
		FSHA1::HashBuffer(Utf8.Get(), Utf8.Length(), Hash);
		Receipt->SetStringField(TEXT("dataDigest"), TEXT("sha1:") + BytesToHex(Hash, 20).ToLower());
	}
	else if (Error != nullptr)
	{
		Receipt->SetObjectField(TEXT("error"), BuildCanonicalError(*Error));
	}
	return Receipt;
}
